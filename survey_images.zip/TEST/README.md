# Survey Images
In each folder in combined and loss_1, you can find 5 images. The ground truth image has the original filename. 

- The black and white image has name like <filename>_0.jpg.
- The loss 1 image has name like <filename>_1.jpg
- The loss 2 and white image has name like <filename>_2.jpg
- The combined image has name like <filename>_3.jpg